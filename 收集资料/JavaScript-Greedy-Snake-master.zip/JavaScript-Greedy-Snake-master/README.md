# JavaScript-Greedy-Snake
原生JavaScript实现贪吃蛇小游戏
